﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Modes {
    public const int
        DYNAMICSEEK = 0,
        DYNAMICFLEE = 1,
        DYNAMICPURSUREARRIVE = 2,
        DYNAMICEVADE = 3,
        DYNAMICALIGN = 4,
        DYNAMICFACE = 5,
        DYNAMICWANDER = 6,
        SMARTERWANDER = 7,
        PATHFOLLOW = 8;
}
